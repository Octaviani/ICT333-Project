package HiveSys.core;

public class StaticSolrConnection extends SolrConnection {

	final static StaticSolrConnection DEFAULT = new StaticSolrConnection();
}
