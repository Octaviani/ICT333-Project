#!/bin/bash

if [ "$#" -ne 2 ]; then
	echo "[x] Usage $0 <directory> <file extension>"
	exit;
fi

#for i in `find $1 -iname *.$2 | cut -c 2-`
for i in `find $1 -iname *.$2`
do
echo $i;
done;




